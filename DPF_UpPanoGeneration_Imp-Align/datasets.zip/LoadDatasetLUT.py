from __future__ import print_function
import os
import cv2
import numpy as np
import random
import torch
from torch.utils import data
from torchvision import transforms
from .util import Equirec2Cube

from skimage import io, transform
from scipy import io as scipyio



def read_list(list_file):
    rgb_depth_list = []
    with open(list_file) as f:
        lines = f.readlines()
        for line in lines:
            rgb_depth_list.append(line.strip().split(" "))
    return rgb_depth_list



def readRGBPano(Imgpath):
    rgb = io.imread(Imgpath).astype(np.float32) / 255.
    #rgb = transform.resize(rgb, (512, 1024))
    tran = transforms.ToTensor()
    rgb = tran(rgb)
    return rgb
        
# def normalize_matrix_to_range(matrix, min_val=-1, max_val=1):
#     """
#     将矩阵归一化到指定的范围内。
#     :param matrix: 要归一化的矩阵。
#     :param min_val: 范围的最小值。
#     :param max_val: 范围的最大值。
#     :return: 归一化后的矩阵。
#     """
#     # 计算最大值和最小值以及范围
#     min_value = np.min(matrix)
#     max_value = np.max(matrix)
#     range_value = max_val - min_val
    
#     # 对矩阵进行归一化
#     normalized_matrix = (matrix - min_value) * range_value / (max_value - min_value)
#     normalized_matrix = normalized_matrix + min_val
    
#     return normalized_matrix


class loadDataLUT(data.Dataset):
    """The Matterport3D Dataset"""

    def __init__(self, root_dir, list_file):
        """
        Args:
            root_dir (string): Directory of the Stanford2D3D Dataset.
            list_file (string): Path to the txt file contain the list of image and depth files.
            height, width: input size.
            disable_color_augmentation, disable_LR_filp_augmentation,
            disable_yaw_rotation_augmentation: augmentation options.
            is_training (bool): True if the dataset is the training set.
        """
        self.root_dir = root_dir
        self.rgb_depth_list = read_list(list_file)
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        self.w = 512
        self.h = 256
        self.e2c = Equirec2Cube(self.h, self.w, self.h // 2)
    
    def __len__(self):
        return len(self.rgb_depth_list)

    def __getitem__(self, idx):
        if torch.is_tensor(idx):
            idx = idx.tolist()

        inputs = {}
        
        # 倾斜图像
        rgb_Rotate_name = os.path.join(self.root_dir, self.rgb_depth_list[idx][0])
        #if os.path.exists(rgb_Rotate_name):
        rgb_rotatedImg = readRGBPano(rgb_Rotate_name)
        inputs["normalized_rgb_Rotate"] = rgb_rotatedImg #self.normalize(rgb_Rotate)
        # 直立图像
        rgb_Upright_name=rgb_Rotate_name.replace("_R512","_Up512")
        # rgb_Upright_name=rgb_Rotate_name.replace("M3D_R","M3D_Up")
        rgb_UprightImg = readRGBPano(rgb_Upright_name)
        inputs["normalized_rgb_Upright"] = rgb_UprightImg
        # 查找表
        LUT_name = os.path.join(self.root_dir, self.rgb_depth_list[idx][1]) #SHAN
        #if os.path.exists(LUT_name):
        LUTMatrix = scipyio.loadmat(LUT_name)
        normalized_LUT=LUTMatrix['LUT']


        normalized_LUT = normalized_LUT.astype(np.float32) # 1*512*1024*3
        normalized_LUT=np.transpose(normalized_LUT, (2,0,1))
        inputs["normalized_LUT_Up"] = normalized_LUT #self.normalize(gt_upright) #SHAN
        
        rgb = cv2.imread(rgb_Rotate_name)
        rgb = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)
        rgb = cv2.resize(rgb, dsize=(self.w, self.h))
        cube_rgb = self.e2c.run(rgb)
        cube_rgb = self.to_tensor(cube_rgb.copy())
        inputs["cube_rgb"] = cube_rgb
        inputs["normalized_cube_rgb"] = torch.stack(torch.split(self.normalize(cube_rgb), self.h // 2, -1), dim=0)
        # 倾斜角
        inputs["PitchRollAng"] = torch.tensor([int(self.rgb_depth_list[idx][2]),int(self.rgb_depth_list[idx][3])])
        
        return inputs
