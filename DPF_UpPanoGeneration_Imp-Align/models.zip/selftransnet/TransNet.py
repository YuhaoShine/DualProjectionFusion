import torch
import torch.nn as nn
import types
import math
import torch.nn.functional as F
import einops

from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from .model_utils import Transformer, Transpose, Interpolate, FeatureFusionBlock_custom

def _make_fusion_block(features, use_bn):
    return FeatureFusionBlock_custom(
        features,
        nn.ReLU(False),
        deconv=False,
        bn=use_bn,
        expand=False,
        align_corners=True,
    )


###############################################################################################
class TransNet(nn.Module):
    def __init__(self, depth=12, heads=16, mlp_dim=2048, dim=1024, image_height=256, image_width=512, pool = 'cls', channels = 3, dim_head = 64, dropout = 0., emb_dropout = 0.):
        super(TransNet, self).__init__()
        ngf = 128
        self.patch_height = 16
        self.patch_width = 16
        cube_height = image_height //2
        cube_width = image_height //2
        num_patches = (image_height// self.patch_height) * (image_width // self.patch_width)  #16*32=512 等矩圆柱中16*16的patch个数
        cube_num_patches = 6 * (cube_height // self.patch_height) * (cube_width // self.patch_width)  #64*6=384 每个cube face有"8*8=64"个16*16的patch
        patch_dim = channels * self.patch_height * self.patch_width # 每个小patch拉成tensor长度是16*16*3=768
        self.to_patch_embedding = nn.Sequential(
            Rearrange('b p c (h p1) (w p2) -> b (p h w) (p1 p2 c)', p1=self.patch_height, p2=self.patch_width),
            nn.Linear(patch_dim, dim),
        ) # patch tensor从768线性投影到1024，每个batch有384个维度1024的patch
        self.pos_embedding = nn.Parameter(torch.randn(1, cube_num_patches, dim)) # 1*384*1024
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout) # 1024, 12, 16, 64, 2048, 0.
        
        self.sigmoid = nn.Sigmoid()

        features = [ngf, ngf//2, ngf//4, 1] # 128,64,32,1

        ##### 取出[4,7,10,12]Encoder输出的[2*384*1024]特征图，再后处理
        self.postprocess1 = nn.Sequential(
            Transpose(1, 2),#B, dim, cube_num_patches 2(batchsize)*1024(patch tensor维度)*384(patch个数)
            nn.Linear(cube_num_patches, num_patches), # 384个“立方体投影patch”[6*8*8] 线性投影 成512个对应于“等矩圆柱投影patch”[16*32]。2*1024*512
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height), w=(image_width // self.patch_width)), # 2*1024*16*32
            nn.Conv2d(
                in_channels=dim,
                out_channels=features[0]*4,
                kernel_size=1,
                stride=1,
                padding=0,
            ), # 2*512*16*32，1*1卷积改变patch tensor维度，1024-->512
            nn.PixelShuffle(2), # 上采样，2*128*32*64
            nn.Conv2d(
                in_channels=features[0],
                out_channels=features[0]*4,
                kernel_size=1,
                stride=1,
                padding=0,
            ), # 2*512*32*64，1*1卷积改变patch tensor维度，128-->512
            nn.PixelShuffle(2), # 上采样，2*128*64*128
            nn.Conv2d(
                in_channels=features[0],
                out_channels=features[0]*4,
                kernel_size=1,
                stride=1,
                padding=0,
            ), # 2*512*64*128，1*1卷积改变patch tensor维度，128-->512
            nn.PixelShuffle(2), #### 上采样，2*128*128*256 ################################# 2*128*128*256 ###### x1
        )
        self.postprocess2 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches),
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height),
                      w=(image_width // self.patch_width)),
            nn.Conv2d(
                in_channels=dim,
                out_channels=features[0] * 4,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
            nn.PixelShuffle(2), # 上采样，2*128*32*64
            nn.Conv2d(
                in_channels=features[0],
                out_channels=features[0] * 4,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
            nn.PixelShuffle(2), #### 上采样，2*128*64*128 ################################# 2*128*64*128 ###### x2
        )
        self.postprocess3 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches),
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height),
                      w=(image_width // self.patch_width)),
            nn.Conv2d(
                in_channels=dim,
                out_channels=features[0] * 4,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
            nn.PixelShuffle(2),  # 上采样，2*128*32*64
            nn.Conv2d(
                in_channels=features[0],
                out_channels=features[0],
                kernel_size=1,
                stride=1,
                padding=0,
            ), #### 2*128*32*64，1*1卷积改变patch tensor维度，128-->128 ################################# 2*128*32*64 ###### x3
        )
        self.postprocess4 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches),
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height),
                      w=(image_width // self.patch_width)),
            nn.Conv2d(
                in_channels=dim,
                out_channels=features[0],
                kernel_size=1,
                stride=1,
                padding=0,
            ), #### 2*128*16*32，1*1卷积改变patch tensor维度，1024-->128 ################################# 2*128*16*32 ###### x4
        )
        use_bn = False
        self.fus1 = _make_fusion_block(features[0], use_bn) # 输入都是128
        self.fus2 = _make_fusion_block(features[0], use_bn)
        self.fus3 = _make_fusion_block(features[0], use_bn)
        self.fus4 = _make_fusion_block(features[0], use_bn)

        self.output_conv = nn.Sequential(
            nn.Conv2d(features[0], features[1], kernel_size=3, stride=1, padding=1), # 128-->64
            nn.ReLU(True),
            nn.Conv2d(features[1], features[2], kernel_size=3, stride=1, padding=1), # 64-->32
            nn.ReLU(True),
            nn.Conv2d(features[2], 3, kernel_size=1, stride=1, padding=0), # 32-->3
        ) #### nn.Conv2d(features[2], 1, kernel_size=1, stride=1, padding=0), nn.ReLU(True),删掉了最后RELU，后面处理完加了sigmoid
        self.hook = [3, 6, 9, 11]

    def forward(self, x): #### 2bs * 6face * 3chanel * 128face_h * 128face_w
        x = self.to_patch_embedding(x) ## 2(batch)*384(6个面，每个面有8*8个patch)*1024(patch尺寸为16*16*3拉成768向量，线性投影为1024)
        x += self.pos_embedding ## 2*384*1024，位置(1*384*1024)嵌入，尺寸没变？？
        x = self.dropout(x)

        features = self.transformer(x) ## list包含12个尺寸为[2*384*1024]的tensor，与输入尺寸相同
        ## 本来每个Encoder的输出都是[2*384*1024]
        # 取出第4个Transformer Encoder输出，再后处理(变换维度+上采样)
        x1 = self.postprocess1(features[self.hook[0]]) # 2*128*128*256
        # 取出第7个Transformer Encoder输出，再后处理
        x2 = self.postprocess2(features[self.hook[1]]) # 2*128*64*128
        # 取出第10个Transformer Encoder输出，再后处理
        x3 = self.postprocess3(features[self.hook[2]]) # 2*128*32*64
        # 取出第12个Transformer Encoder输出，再后处理
        x4 = self.postprocess4(features[self.hook[3]]) # 2*128*16*32

        path3 = self.fus4(x4) # 2*128*32*64
        path2 = self.fus3(path3, x3) # 2*128*64*128
        path1 = self.fus2(path2, x2) # 2*128*128*256
        path0 = self.fus1(path1, x1) # 2*128*256*512
        x = self.output_conv(path0) # 2*3*256*512
        x = self.sigmoid(x)*2-1 ##
        return x, path0, path1, path2, path3
