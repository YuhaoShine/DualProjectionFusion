# from .spherenet import SphereAdjust
import torch
from torch import nn
import torch.nn.functional as F
import numpy as np

from .TransNetUpConvnextLike import TransNet



###############################################################################################
class TransformerNet(nn.Module):
    def __init__(self, image_height=256, image_width=512):
        super(TransformerNet, self).__init__()
        self.transformer_module = TransNet(image_height=image_height, image_width=image_width)

    def forward(self, x):
        outputs = self.transformer_module(x)
        return outputs