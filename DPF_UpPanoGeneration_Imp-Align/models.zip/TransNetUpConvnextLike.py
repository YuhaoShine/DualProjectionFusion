import torch
import torch.nn as nn
import types
import math
import torch.nn.functional as F
import einops

from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from .selftransnet.model_utils import Transformer, Transpose, Interpolate, FeatureFusionBlock_custom
import numpy as np
from collections import OrderedDict

def _make_fusion_block(features, use_bn):
    return FeatureFusionBlock_custom(
        features,
        nn.ReLU(False),
        deconv=False,
        bn=use_bn,
        expand=False,
        align_corners=True,
    )


###############################################################################################
class TransNet(nn.Module):
    def __init__(self, depth=12, heads=16, mlp_dim=3072, dim=768, image_height=256, image_width=512, pool = 'cls', channels = 3, dim_head = 48, dropout = 0., emb_dropout = 0.):
        super(TransNet, self).__init__()
        ngf = 128
        self.patch_height = 16
        self.patch_width = 16
        cube_height = image_height //2
        cube_width = image_height //2
        num_patches = (image_height// self.patch_height) * (image_width // self.patch_width)  
        cube_num_patches = 6 * (cube_height // self.patch_height) * (cube_width // self.patch_width)  
        patch_dim = channels * self.patch_height * self.patch_width
        self.to_patch_embedding = nn.Sequential(
            Rearrange('b p c (h p1) (w p2) -> b (p h w) (p1 p2 c)', p1=self.patch_height, p2=self.patch_width),
            nn.Linear(patch_dim, dim),
        )
        self.pos_embedding = nn.Parameter(torch.randn(1, cube_num_patches, dim)) # 1*384*768
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout) # 768, 12, 16, 48, 3072, 0.
        
        self.sigmoid = nn.Sigmoid()
        #############################################################################################################################
        features = [ngf, ngf//2, ngf//4, 1] # 128,64,32,1
        #############################################################################################################################
        self.postprocess1 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches), 
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height), w=(image_width // self.patch_width)), 
            nn.Conv2d(
                in_channels=dim,
                out_channels=features[0]*4,
                kernel_size=1,
                stride=1,
                padding=0,
            ), 
            nn.PixelShuffle(2), 
            nn.Conv2d(
                in_channels=features[0],
                out_channels=features[0]*4,
                kernel_size=1,
                stride=1,
                padding=0,
            ), 
            nn.PixelShuffle(2), 
        )
        #############################################################################################################################
        self.postprocess2 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches),
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height), w=(image_width // self.patch_width)), # 2*768*16*32
            nn.Conv2d(
                in_channels=dim,
                out_channels=features[0] * 4,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
            nn.PixelShuffle(2),
            nn.Conv2d(
                in_channels=features[0],
                out_channels=features[0] * 4,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
            nn.PixelShuffle(2),
        )
        #############################################################################################################################
        self.postprocess3 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches),
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height), w=(image_width // self.patch_width)), # 2*768*16*32
            nn.Conv2d(
                in_channels=dim,
                out_channels=256 * 4,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
            nn.PixelShuffle(2), 
            nn.Conv2d(
                in_channels=256,
                out_channels=256,
                kernel_size=1,
                stride=1,
                padding=0,
            ),
        )
        #############################################################################################################################
        self.postprocess4 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches),
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height), w=(image_width // self.patch_width)), # 2*768*16*32
            nn.Conv2d(
                in_channels=dim,
                out_channels=512,
                kernel_size=1,
                stride=1,
                padding=0,
            ), 
        )
        #############################################################################################################################
        self.postprocess5 = nn.Sequential(
            Transpose(1, 2),
            nn.Linear(cube_num_patches, num_patches),
            Rearrange('b c (h w) -> b c h w', h=(image_height // self.patch_height), w=(image_width // self.patch_width)), # 2*768*16*32
            nn.Conv2d(
                in_channels=dim,
                out_channels=1024,
                kernel_size=2,
                stride=2,
                padding=0,
            ), 
        )
        #############################################################################################################################
        self.hook = [3, 5, 7, 9, 11]

    def forward(self, x): 
        x = self.to_patch_embedding(x) 
        x += self.pos_embedding 
        x = self.dropout(x)

        features = self.transformer(x) 
        x1 = self.postprocess1(features[self.hook[0]])
        x2 = self.postprocess2(features[self.hook[1]])
        x3 = self.postprocess3(features[self.hook[2]]) 
        x4 = self.postprocess4(features[self.hook[3]])
        x5 = self.postprocess5(features[self.hook[4]]) 
        
        return x1, x2, x3, x4, x5
