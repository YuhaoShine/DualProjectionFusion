import torch
import torch.nn as nn
import torch.nn.functional as F


class HFMblock(nn.Module): ## HFM模块
    def __init__(self):
        super(HFMblock, self).__init__()
        self.down = nn.AvgPool2d(kernel_size=2)
        # self.att = CALayer(n_feats)
    def forward(self, x): # 输入三通道RGB
        x1 = self.down(x) # 2*2平均池化
        high = x - F.interpolate(x1, size = x.size()[-2:], mode='bilinear', align_corners=True) ## ????
        return high + x

## Channel Attention (CA) Layer
class CALayer(nn.Module):
    def __init__(self, channel, reduction=0.8):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1) 
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, round(channel*reduction), 1, padding=0, bias=True),
                # 32, 2, 1, 0
                nn.ReLU(inplace=True),
                nn.Conv2d(round(channel*reduction), channel, 1, padding=0, bias=True),
                # 2, 32, 1, 0
                nn.Sigmoid()
        )
    def forward(self, x):
        y = self.avg_pool(x) # 平均池化输出32*1向量
        y = self.conv_du(y) # 32维，和为1，的向量，表示32个通道的重要性
        return x * y # 返回通道和其重要程度的乘积

