import torch
import torch.nn as nn
import numpy as np
import copy

from .convnextSelfPaddingHFM import *


    
class Equi_convnextSHAN(nn.Module):
    def __init__(self, num_layers, equi_h, equi_w, pretrained=False, **kwargs):
        super(Equi_convnextSHAN, self).__init__()
        self.num_layers = num_layers
        self.equi_h = equi_h
        self.equi_w = equi_w
        self.cube_h = equi_h//2
        self.equi_encoder = convnext_base(pretrained)
        

    def forward(self, input_equi_image):
        bs, c, erp_h, erp_w = input_equi_image.shape 
        equi_enc_feat0,equi_enc_feat1,equi_enc_feat2,equi_enc_feat3,equi_enc_feat4 = self.equi_encoder(input_equi_image)
        outputs = {}
        outputs["equi_enc_feat0"] = equi_enc_feat0 ##  F0: 128*64*128
        outputs["equi_enc_feat1"] = equi_enc_feat1 ##  F1: 128*64*128
        outputs["equi_enc_feat2"] = equi_enc_feat2 ##  F2: 256*32*64
        outputs["equi_enc_feat3"] = equi_enc_feat3 ##  F3: 512*16*32
        outputs["equi_enc_feat4"] = equi_enc_feat4 ##  F4：1024*8*16    
        return outputs

    
