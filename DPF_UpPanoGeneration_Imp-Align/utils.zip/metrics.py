import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
import torch
import math

from skimage import io, transform
from torchvision import transforms
import numpy as np
import lpips



def calculate_psnr(target, prediction):
    assert target.shape == prediction.shape, "The shape of target and prediction must be the same."
    target = target.type(torch.float32)
    prediction = prediction.type(torch.float32)
    diff = target - prediction
    diff = torch.abs(diff) 
    mse = torch.mean(diff ** 2)
    max_pixel_value = 1.0  
    psnr = 20 * math.log10(max_pixel_value / math.sqrt(mse))
    psnr = torch.tensor(psnr)   
    return psnr



def compute_depth_metrics(gt, pred, lpips_model):
    """Computation of metrics between predicted and ground truth depths
    """
    thresh = torch.max((gt / pred), (pred / gt))
    a1 = (thresh < 1.25     ).float().mean()
    rmse = (gt - pred) ** 2
    rmse = torch.sqrt(rmse.mean())
    abs_ = torch.mean(torch.abs(gt - pred))
    PSNR=calculate_psnr(gt, pred)
    
    LPIPSs = lpips_model(gt, pred)
    LPI=LPIPSs.squeeze()
    LPI = torch.mean(LPI)

    return abs_, rmse, a1, PSNR, LPI


# From https://github.com/fyu/drn
class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.vals = []
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.vals.append(val)
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def to_dict(self):
        return {
            'val': self.val,
            'sum': self.sum,
            'count': self.count,
            'avg': self.avg
        }

    def from_dict(self, meter_dict):
        self.val = meter_dict['val']
        self.sum = meter_dict['sum']
        self.count = meter_dict['count']
        self.avg = meter_dict['avg']


class Evaluator(object): ##

    def __init__(self, median_align=False):

        self.median_align = median_align
        self.metrics = {}
        self.metrics["err/abs_"] = AverageMeter()
        self.metrics["err/rms"] = AverageMeter()
        self.metrics["acc/a1"] = AverageMeter()
        self.metrics["acc/PSNR"] = AverageMeter()
        self.metrics["err/LPIPSs"] = AverageMeter()

    def reset_eval_metrics(self):
        """
        Resets metrics used to evaluate the model
        """
        self.metrics["err/abs_"].reset()
        self.metrics["err/rms"].reset()
        self.metrics["acc/a1"].reset()
        self.metrics["acc/PSNR"].reset()
        self.metrics["err/LPIPSs"].reset()

    def compute_eval_metrics(self, gt_depth, pred_depth, lpips_model):
        """
        Computes metrics used to evaluate the model
        """
        N = gt_depth.shape[0]
        
        abs_, rms, a1, PSNR, LPIPSs = compute_depth_metrics(gt_depth, pred_depth, lpips_model)

        self.metrics["err/abs_"].update(abs_, N)
        self.metrics["err/rms"].update(rms, N)
        self.metrics["acc/a1"].update(a1, N)
        self.metrics["acc/PSNR"].update(PSNR, N)
        self.metrics["err/LPIPSs"].update(LPIPSs, N)
        
        return abs_, rms, a1, PSNR, LPIPSs

    def print(self, epoch, dir=None):
        avg_metrics = []
        avg_metrics.append(self.metrics["err/abs_"].avg)
        avg_metrics.append(self.metrics["err/rms"].avg)
        avg_metrics.append(self.metrics["acc/a1"].avg)
        avg_metrics.append(self.metrics["acc/PSNR"].avg)
        avg_metrics.append(self.metrics["err/LPIPSs"].avg)
        avg_metrics.append(epoch)
        
        print("\n  "+ ("{:>9} | " * 5).format("abs_", "rms", "a1", "PSNR", "LPIPSs"))
        print(("&  {: 8.5f} " * 5).format(*avg_metrics))

        if dir is not None:
            file = os.path.join(dir, "backbone_result.txt")
            
            with open(file, 'a') as f:
                print("\n  " + ("{:>9} | " * 6).format("abs_", "rms", "a1", "PSNR", "LPIPSs", "epoch"), file=f)
                print(("&  {: 8.5f} " * 6).format(*avg_metrics), file=f)