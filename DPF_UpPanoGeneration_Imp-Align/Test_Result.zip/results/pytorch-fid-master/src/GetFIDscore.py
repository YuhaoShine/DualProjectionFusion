import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
import cv2
from pytorch_fid import fid_score

def calculate_fid(real_images_path, generated_images_path):
    """
    Calculate FID score between real and generated images.
    
    :param real_images_path: Path to the directory containing real images.
    :param generated_images_path: Path to the directory containing generated images.
    :return: FID score
    """
    fid = fid_score.calculate_fid_given_paths([real_images_path, generated_images_path], batch_size=64, device='cuda', dims=2048)
    return fid


if __name__ == '__main__':
    
    real_images_path = '../../gt_UpIMG'  # Replace with the path to real images
    generated_images_path = '../../pre_UpIMG'
    
    fid = calculate_fid(real_images_path, generated_images_path)
    print(f'FID: {fid}')
