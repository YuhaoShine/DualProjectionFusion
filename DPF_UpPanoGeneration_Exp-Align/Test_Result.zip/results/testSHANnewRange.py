import math
from skimage import io, transform
import torch
import numpy as np
import torch.nn as nn
from torchvision import transforms
from scipy.io import loadmat
from scipy.io import loadmat
from scipy.io import savemat


def readRGBPano(Imgpath):
    rgb = io.imread(Imgpath).astype(np.float32) / 255.
    rgb = transform.resize(rgb, (256, 512))
    tran = transforms.ToTensor()
    rgb = tran(rgb)
    return rgb


path1 = r"F:\pingjiashiyan4paper\SUN360\Test_Result\results\TestSetEpoch100\GT.mat"
RealLabel = loadmat(path1)
Phi_and_The_gt = RealLabel['GT']  # 17825*2

path2 = r"F:\pingjiashiyan4paper\SUN360\Test_Result\results\TestSetEpoch100\PRE.mat"
PreLabel = loadmat(path2)
Phi_and_The_pre = PreLabel['PRE']  # 17825*2

PredictAngs_in = []



for i in range(len(Phi_and_The_gt)):
    
    if abs(Phi_and_The_gt[i,0]) <= 90 and abs(Phi_and_The_gt[i,1]) <= 90 and abs(Phi_and_The_gt[i,0]) > 80 and abs(Phi_and_The_gt[i,1]) > 80:
        ErrPR = Phi_and_The_pre[i,:] - Phi_and_The_gt[i,:]
        
        dif_p = ErrPR[0]
        dif_r = ErrPR[1]
        dif_r = dif_r/180 * math.pi
        dif_p = dif_p/180 * math.pi
        Rx = np.mat([[1, 0, 0], [0, math.cos(dif_r), -math.sin(dif_r)],
                    [0, math.sin(dif_r), math.cos(dif_r)]])
        Ry = np.mat([[math.cos(dif_p), 0, math.sin(dif_p)], [
                    0, 1, 0], [-math.sin(dif_p), 0, math.cos(dif_p)]])
        Rz = np.mat([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
        R = Rx * Ry * Rz
        
        upright = np.array([0, 0, 1])
        upright_pred = np.dot(R, upright.T)
        upright_pred = upright_pred.A
        dif = math.acos(np.dot(upright,upright_pred.T))
        PredictAngle = dif/math.pi * 180  # print('夹角:',dif)
        #print(PredictAngle,'  Img_',i)
        PredictAngs_in.append(PredictAngle)
    

ErrAngs90 = np.array(PredictAngs_in)
mat_dict = {'ErrAngs90': ErrAngs90}
savemat('ErrAngs90.mat', mat_dict)







# for i in range(len(Phi_and_The_gt)):
    
#     if abs(Phi_and_The_gt[i,0]) <= 30 and abs(Phi_and_The_gt[i,1]) <= 30:
#         ErrPR = Phi_and_The_pre[i,:] - Phi_and_The_gt[i,:]
        
#         dif_p = ErrPR[0]
#         dif_r = ErrPR[1]
#         dif_r = dif_r/180 * math.pi
#         dif_p = dif_p/180 * math.pi
#         Rx = np.mat([[1, 0, 0], [0, math.cos(dif_r), -math.sin(dif_r)],
#                     [0, math.sin(dif_r), math.cos(dif_r)]])
#         Ry = np.mat([[math.cos(dif_p), 0, math.sin(dif_p)], [
#                     0, 1, 0], [-math.sin(dif_p), 0, math.cos(dif_p)]])
#         Rz = np.mat([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
#         R = Rx * Ry * Rz
        
#         upright = np.array([0, 0, 1])
#         upright_pred = np.dot(R, upright.T)
#         upright_pred = upright_pred.A
#         dif = math.acos(np.dot(upright,upright_pred.T))
#         PredictAngle = dif/math.pi * 180  # print('夹角:',dif)
#         #print(PredictAngle,'  Img_',i)
#         PredictAngs_in.append(PredictAngle)
    

# ErrAngs=PredictAngs_in

# E1 = [val for val in ErrAngs if val <= 1]
# E2 = [val for val in ErrAngs if val <= 2]
# E3 = [val for val in ErrAngs if val <= 3]
# E4 = [val for val in ErrAngs if val <= 4]
# E5 = [val for val in ErrAngs if val <= 5]
# E7_5 = [val for val in ErrAngs if val <= 7.5]
# E10 = [val for val in ErrAngs if val <= 10]
# E12 = [val for val in ErrAngs if val <= 12]
# E15 = [val for val in ErrAngs if val <= 15]
# LL = len(ErrAngs)
# PersentageALL = [round(len(E1)/LL,4), round(len(E2)/LL,4), round(len(E3)/LL,4), round(len(E4)/LL,4), round(len(E5)/LL,4), 
#                       round(len(E7_5)/LL,4), round(len(E10)/LL,4), round(len(E12)/LL,4), round(len(E15)/LL,4)]
# print('准确率： ', PersentageALL)

# E1 = [val for val in ErrAngs if val <= 1]
# E2 = [val for val in ErrAngs if val <= 2]
# E3 = [val for val in ErrAngs if val <= 3]
# E4 = [val for val in ErrAngs if val <= 4]
# E5 = [val for val in ErrAngs if val <= 5]
# E6 = [val for val in ErrAngs if val <= 6]
# E7 = [val for val in ErrAngs if val <= 7]
# E8 = [val for val in ErrAngs if val <= 8]
# E9 = [val for val in ErrAngs if val <= 9]
# E10 = [val for val in ErrAngs if val <= 10]
# E11 = [val for val in ErrAngs if val <= 11]
# E12 = [val for val in ErrAngs if val <= 12]
# E13 = [val for val in ErrAngs if val <= 13]
# E14 = [val for val in ErrAngs if val <= 14]
# E15 = [val for val in ErrAngs if val <= 15]
# LL = len(ErrAngs)
# PersentageALL = [round(len(E1)/LL,4), round(len(E2)/LL,4), round(len(E3)/LL,4), round(len(E4)/LL,4), round(len(E5)/LL,4), 
#                  round(len(E6)/LL,4), round(len(E7)/LL,4), round(len(E8)/LL,4), round(len(E9)/LL,4), round(len(E10)/LL,4),
#                  round(len(E11)/LL,4), round(len(E12)/LL,4), round(len(E13)/LL,4), round(len(E14)/LL,4), round(len(E15)/LL,4)]
# print('准确率： ', PersentageALL)