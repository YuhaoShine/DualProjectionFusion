close all;clear;clc
GT=load('PitchRollAngGT.txt');
PRE=load('PitchRollAngPRED.txt');
PRE=round(PRE,2);
save('GT.mat','GT')
save('PRE.mat','PRE')