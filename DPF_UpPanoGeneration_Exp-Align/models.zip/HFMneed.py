import torch
import torch.nn as nn
import torch.nn.functional as F


class HFMblock(nn.Module): 
    def __init__(self):
        super(HFMblock, self).__init__()
        self.down = nn.AvgPool2d(kernel_size=2)
    def forward(self, x): 
        x1 = self.down(x) 
        high = x - F.interpolate(x1, size = x.size()[-2:], mode='bilinear', align_corners=True) 
        return high + x

class CALayer(nn.Module):
    def __init__(self, channel, reduction=0.8):
        super(CALayer, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1) 
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, round(channel*reduction), 1, padding=0, bias=True),
                nn.ReLU(inplace=True),
                nn.Conv2d(round(channel*reduction), channel, 1, padding=0, bias=True),
                nn.Sigmoid()
        )
    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y) 
        return x * y 

