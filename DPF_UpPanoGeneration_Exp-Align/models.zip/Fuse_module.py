import torch
from torch import nn
import torch.nn.functional as F
import numpy as np
import sys
import os
from collections import OrderedDict
from .layersSelfPadding import Conv3x3, ConvBlock, upsample, subpixelconvolution
from .HFMneed import CALayer


class Conv3x3(nn.Module):
    """Layer to pad and convolve input
    """
    def __init__(self, in_channels, out_channels, bias=True):
        super(Conv3x3, self).__init__()
        self.conv = nn.Conv2d(int(in_channels), int(out_channels), 3, bias=bias)

    def forward(self, x):
        x = F.pad(x, (1, 1, 0, 0), mode='circular') 
        out = F.pad(x, (0, 0, 1, 1), mode='constant',value=0) 
        out = self.conv(out)
        return out

def conv1x1(in_planes, out_planes, stride=1):
    """1x1 convolution"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=1, stride=stride, bias=False)

#################################################################################################
class FeatureFusionBlock_ADD(nn.Module):
    def __init__(self, planes, stride=1):
        super(FeatureFusionBlock_ADD, self).__init__()
        norm_layer = nn.BatchNorm2d
        #self.conv1 = conv3x3(planes, planes)
        self.conv1 = Conv3x3(planes, planes)
        self.conv2 = conv1x1(planes, planes)
        #self.conv3 = conv3x3(planes, planes)
        self.conv3 = Conv3x3(planes, planes)
        self.conv4 = ResBlock(planes, planes)

        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x1, x2):
        x = x1+x2
        x = self.conv1(x)
        x = self.relu(x)
        x = self.conv2(x)
        attn = self.sigmoid(x)
        x1 = x1 * attn
        x2 = x2 * (1-attn)
        out = x1+x2
        out = self.conv3(out)
        out = self.relu(out)
        out = self.conv4(out)
        return out

#################################################################################################
class ResBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None, groups=1,
                 base_width=64, dilation=1, norm_layer=None):
        super(ResBlock, self).__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        if groups != 1 or base_width != 64:
            raise ValueError('BasicBlock only supports groups=1 and base_width=64')
        if dilation > 1:
            raise NotImplementedError("Dilation > 1 not supported in BasicBlock")
        self.ifshift = False
        if inplanes != planes:
            self.ifshift = True
            self.shift = conv1x1(inplanes, planes, 1)
        #self.conv1 = conv3x3(inplanes, planes, 1, stride)
        self.conv1 = Conv3x3(inplanes, planes)

        self.bn1 = norm_layer(planes)
        self.relu = nn.ReLU(inplace=True)

        #self.conv2 = conv3x3(planes, planes, 1)
        self.conv2 = Conv3x3(planes, planes)

        self.bn2 = norm_layer(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(identity)
        if self.ifshift:
            identity = self.shift(identity)
        out += identity
        out = self.relu(out)

        return out


#################################################################################################
class ConvModule(nn.Module):

    def __init__(self, inplanes, planes, kernel_size=3, stride=1, padding=1, dilation=1,
                 bn=False,
                 maxpool=False, pool_kernel=3, pool_stride=2, pool_pad=1):
        super(ConvModule, self).__init__()
        conv2d = Conv3x3(inplanes, planes)
        layers = []
        if bn:
            layers += [nn.BatchNorm2d(planes), nn.ReLU(inplace=True)]
        else:
            layers += [nn.ReLU(inplace=True)] 
        if maxpool: 
            layers += [nn.MaxPool2d(kernel_size=pool_kernel, stride=pool_stride,padding=pool_pad)]

        self.layers = nn.Sequential(*([conv2d]+layers))
    def forward(self, x):
        x = self.layers(x) 
        return x

#################################################################################################
class ConvModuleNoRELU(nn.Module):

    def __init__(self, inplanes, planes, kernel_size=3, stride=1, padding=1, dilation=1,
                 bn=False,
                 maxpool=False, pool_kernel=3, pool_stride=2, pool_pad=1):
        super(ConvModuleNoRELU, self).__init__()
        conv2d = Conv3x3(inplanes, planes)

    def forward(self, x):
        x = self.conv2d(x)
        return x
    
###############################################################################################
class Fuse_module(nn.Module):
    def __init__(self, batch_norm=False):
        super(Fuse_module, self).__init__()
        use_bn = False
        self.fus1 = FeatureFusionBlock_ADD(128)
        self.fus2 = FeatureFusionBlock_ADD(128)
        self.fus3 = FeatureFusionBlock_ADD(256)
        self.fus4 = FeatureFusionBlock_ADD(512)
        self.fus5 = FeatureFusionBlock_ADD(1024)
        #############################################################################################################################
        self.num_ch_enc = np.array([128, 128, 256, 512, 1024])
        self.num_ch_dec = np.array([32, 64, 128, 256, 512])
        ##############################################
        self.equi_dec_convs = OrderedDict()
        self.equi_dec_convs["upconv_5"] = ConvBlock(self.num_ch_enc[4], self.num_ch_dec[4])
        self.equi_dec_convs["deconv_4"] = ConvBlock(self.num_ch_dec[4] + self.num_ch_enc[3], self.num_ch_dec[4])
        self.equi_dec_convs["upconv_4"] = ConvBlock(self.num_ch_dec[4], self.num_ch_dec[3])
        self.equi_dec_convs["deconv_3"] = ConvBlock(self.num_ch_dec[3] + self.num_ch_enc[2], self.num_ch_dec[3])
        self.equi_dec_convs["upconv_3"] = ConvBlock(self.num_ch_dec[3], self.num_ch_dec[2]) 
        self.equi_dec_convs["deconv_2"] = ConvBlock(self.num_ch_dec[2] + self.num_ch_enc[1], self.num_ch_dec[2])
        self.equi_dec_convs["upconv_2"] = ConvBlock(self.num_ch_dec[2], self.num_ch_dec[1])
        self.equi_dec_convs["deconv_1"] = ConvBlock(self.num_ch_dec[1] + self.num_ch_enc[0], self.num_ch_dec[1]) 
        self.equi_dec_convs["upconv_1"] = ConvBlock(self.num_ch_dec[1], self.num_ch_dec[0]*16) 
        self.equi_dec_convs["deconv_0"] = ConvBlock(self.num_ch_dec[0], self.num_ch_dec[0]) 
        self.equi_dec_convs["depthconv_0"] = Conv3x3(self.num_ch_dec[0], 3) 
        self.equi_decoder_convs = nn.ModuleList(list(self.equi_dec_convs.values()))
        ###############################################
        self.sigmoid = nn.Sigmoid()
        self.fc = nn.Linear(1024, 2)
        self.sigmoid1 = nn.Sigmoid()
        self.avgpool8 = nn.AdaptiveAvgPool2d((1,1))
        self.att0 = CALayer(128)
        self.att1 = CALayer(128)
        self.att2 = CALayer(256)
        self.att3 = CALayer(512)
        self.att4 = CALayer(1024)
        #############################################################################################################################

    def forward(self, Tf1, Tf2, Tf3, Tf4, Tf5, Cf1, Cf2, Cf3, Cf4, Cf5):
        TCf1=self.fus1(Tf1,Cf1)
        TCf2=self.fus2(Tf2,Cf2)
        TCf3=self.fus3(Tf3,Cf3)
        TCf4=self.fus4(Tf4,Cf4)
        TCf5=self.fus5(Tf5,Cf5)

        TCf1 = self.att0(TCf1)
        TCf2 = self.att1(TCf2)
        TCf3 = self.att2(TCf3)
        TCf4 = self.att3(TCf4)
        TCf5 = self.att4(TCf5)

        p_and_R_Angle = self.avgpool8(Cf5)
        p_and_R_Angle = p_and_R_Angle.view(p_and_R_Angle.size(0), -1)
        p_and_R_Angle = self.fc(p_and_R_Angle)
        p_and_R_Angle = self.sigmoid1(p_and_R_Angle)

        equi_x = TCf5 ## F4：[1024*8*16]
        equi_x = upsample(self.equi_dec_convs["upconv_5"](equi_x)) 
        #####################################################################################################
        equi_x = torch.cat([equi_x, TCf4], 1) 
        equi_x = self.equi_dec_convs["deconv_4"](equi_x) 
        equi_x = upsample(self.equi_dec_convs["upconv_4"](equi_x)) 
        #####################################################################################################
        equi_x = torch.cat([equi_x, TCf3], 1) 
        equi_x = self.equi_dec_convs["deconv_3"](equi_x) 
        equi_x = upsample(self.equi_dec_convs["upconv_3"](equi_x)) 
        #####################################################################################################
        equi_x = torch.cat([equi_x, TCf2], 1)
        equi_x = self.equi_dec_convs["deconv_2"](equi_x) 
        equi_x =self.equi_dec_convs["upconv_2"](equi_x) 
        #####################################################################################################
        equi_x = torch.cat([equi_x, TCf1], 1) 
        equi_x = self.equi_dec_convs["deconv_1"](equi_x) 
        equi_x = subpixelconvolution(self.equi_dec_convs["upconv_1"](equi_x)) 
        #####################################################################################################
        equi_x = self.equi_dec_convs["deconv_0"](equi_x) 
        equi_upright = self.equi_dec_convs["depthconv_0"](equi_x) 
        pred_Upright = self.sigmoid(equi_upright)*2-1 
        
        outputs = {}
        outputs["pred_Upright"] = pred_Upright 
        outputs["TCf1"] = TCf1 
        outputs["TCf2"] = TCf2 
        outputs["TCf3"] = TCf3 
        outputs["TCf4"] = TCf4 
        outputs["TCf5"] = TCf5 
        outputs["PitchRoll_norm_pred"] = p_and_R_Angle * 180 - 90
        
        return outputs


