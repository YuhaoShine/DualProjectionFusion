from .TransformerNet import TransformerNet
from .Equi_convnextSHAN import Equi_convnextSHAN
from .Fuse_module import Fuse_module
import torch
from torch import nn
import torch.nn.functional as F
import numpy as np
import sys
import os
from collections import OrderedDict

   
###############################################################################################
class TwoBranchConvNextViT(nn.Module): 
    '''
    use global and local feature
    '''
    def __init__(self, image_height=256, image_width=512):
        super(TwoBranchConvNextViT, self).__init__()
        self.Transformer_branch = TransformerNet(image_height=image_height, image_width=image_width)
        self.ConvNext_branch = Equi_convnextSHAN(18, 256, 512, True)
        self.fuse_branch = Fuse_module()

    def forward(self, img, cubemap):
        Tf1, Tf2, Tf3, Tf4, Tf5 = self.Transformer_branch(cubemap) 
        ConVNext_Results = self.ConvNext_branch(img)
        Cf1=ConVNext_Results["equi_enc_feat0"]
        Cf2=ConVNext_Results["equi_enc_feat1"]
        Cf3=ConVNext_Results["equi_enc_feat2"]
        Cf4=ConVNext_Results["equi_enc_feat3"]
        Cf5=ConVNext_Results["equi_enc_feat4"]
        
        fus_result = self.fuse_branch(Tf1, Tf2, Tf3, Tf4, Tf5, Cf1, Cf2, Cf3, Cf4, Cf5) 
        
        return fus_result    
###############################################################################################

