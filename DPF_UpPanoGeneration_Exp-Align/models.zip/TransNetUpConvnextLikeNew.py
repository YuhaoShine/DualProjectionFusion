import torch
import torch.nn as nn
import types
import math
import torch.nn.functional as F
import einops
from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from .selftransnet.model_utils import Transformer, Transpose, Interpolate, FeatureFusionBlock_custom
import numpy as np
from .layersSelfPadding import Conv3x3, ConvBlock, upsample, subpixelconvolution
from collections import OrderedDict
import sys
import os
import matplotlib.pyplot as plt
sys.path.append('H:/DPF_UpPanoGeneration_Exp-Align/datasets')
from Cube2EquirecGPU import cub2erp_batch


def _make_fusion_block(features, use_bn):
    return FeatureFusionBlock_custom(
        features,
        nn.ReLU(False),
        deconv=False,
        bn=use_bn,
        expand=False,
        align_corners=True,
    )


def vitMatrix2ERP(vitMatrix): 
    TT=Transpose(1, 2)
    vitMatrix=TT(vitMatrix) 
    RR=Rearrange('b (p1 p2 c) (p h w) -> b p c (h p1) (w p2)', p=6, c=3, h=8, w=8, p1=16, p2=16)
    CubeLike=RR(vitMatrix) 
    CubeLike[:,4,:,:,:]=torch.rot90(CubeLike[:,4,:,:,:], k=-1, dims=[2, 3])
    CubeLike[:,5,:,:,:]=torch.rot90(CubeLike[:,5,:,:,:], k=-1, dims=[2, 3])
    EEgpu=cub2erp_batch(CubeLike)
    image_normalizedgpu = (EEgpu - EEgpu.min()) / (EEgpu.max() - EEgpu.min()) 
    ERP_tensor = image_normalizedgpu.float()
    return ERP_tensor 
    
###############################################################################################
class TransNet(nn.Module):
    def __init__(self, depth=12, heads=16, mlp_dim=3072, dim=768, image_height=256, image_width=512, pool = 'cls', channels = 3, dim_head = 48, dropout = 0., emb_dropout = 0.):
        super(TransNet, self).__init__()
        ngf = 128
        self.patch_height = 16
        self.patch_width = 16
        cube_height = image_height //2
        cube_width = image_height //2
        num_patches = (image_height// self.patch_height) * (image_width // self.patch_width)  
        cube_num_patches = 6 * (cube_height // self.patch_height) * (cube_width // self.patch_width)  
        patch_dim = channels * self.patch_height * self.patch_width 
        self.to_patch_embedding = nn.Sequential(
            Rearrange('b p c (h p1) (w p2) -> b (p h w) (p1 p2 c)', p1=self.patch_height, p2=self.patch_width),
            nn.Linear(patch_dim, dim),
        ) 
        self.pos_embedding = nn.Parameter(torch.randn(1, cube_num_patches, dim)) 
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, mlp_dim, dropout) 
        
        self.sigmoid = nn.Sigmoid()
        
        features = [ngf, ngf//2, ngf//4, 1] # 128,64,32,1
        
        self.postprocess1 = nn.Sequential(
            # 目标：bs*3*256*512-->bs*128*64*128
            nn.PixelUnshuffle(downscale_factor=2), # bs*12*128*256
            nn.Conv2d(3 * 4, 32, kernel_size=1), # bs*32*128*256
            nn.PixelUnshuffle(downscale_factor=2), # bs*128*64*128
        )
        self.postprocess2 = nn.Sequential(
            # 目标：bs*3*256*512-->bs*128*64*128
            nn.PixelUnshuffle(downscale_factor=2), # bs*12*128*256
            nn.Conv2d(3 * 4, 32, kernel_size=1), # bs*32*128*256
            nn.PixelUnshuffle(downscale_factor=2), # bs*128*64*128
        )
        self.postprocess3 = nn.Sequential(
            # 目标：bs*3*256*512-->bs*256*32*64
            nn.PixelUnshuffle(downscale_factor=2), # bs*12*128*256
            nn.PixelUnshuffle(downscale_factor=2), # bs*48*64*128
            nn.Conv2d(48, 64, kernel_size=1), # bs*64*64*128
            nn.PixelUnshuffle(downscale_factor=2), # bs*256*32*64
        )
        self.postprocess4 = nn.Sequential(
            # 目标：bs*3*256*512-->bs*512*16*32
            nn.PixelUnshuffle(downscale_factor=2), # bs*12*128*256
            nn.PixelUnshuffle(downscale_factor=2), # bs*48*64*128
            nn.PixelUnshuffle(downscale_factor=2), # bs*192*32*64
            nn.Conv2d(192, 128, kernel_size=1), # bs*128*32*64
            nn.PixelUnshuffle(downscale_factor=2), # bs*512*16*32
        )
        self.postprocess5 = nn.Sequential(
            # 目标：bs*3*256*512-->bs*1024*8*16
            nn.PixelUnshuffle(downscale_factor=2), # bs*12*128*256
            nn.PixelUnshuffle(downscale_factor=2), # bs*48*64*128
            nn.PixelUnshuffle(downscale_factor=2), # bs*192*32*64
            nn.Conv2d(192, 64, kernel_size=1), # bs*128*32*64
            nn.PixelUnshuffle(downscale_factor=2), # bs*256*16*32
            nn.PixelUnshuffle(downscale_factor=2), # bs*1024*8*16
        )
        #############################################################################################################################
        self.num_ch_enc = np.array([128, 128, 256, 512, 1024]) 
        
        self.num_ch_dec = np.array([32, 64, 128, 256, 512])
        
        self.equi_dec_convs = OrderedDict()

        self.equi_dec_convs["upconv_5"] = ConvBlock(self.num_ch_enc[4], self.num_ch_dec[4]) # 1024-->512
        
        self.equi_dec_convs["deconv_4"] = ConvBlock(self.num_ch_dec[4] + self.num_ch_enc[3], self.num_ch_dec[4]) # 512+512拼1024-->512
        self.equi_dec_convs["upconv_4"] = ConvBlock(self.num_ch_dec[4], self.num_ch_dec[3]) # 512-->256

        self.equi_dec_convs["deconv_3"] = ConvBlock(self.num_ch_dec[3] + self.num_ch_enc[2], self.num_ch_dec[3]) # 256+256拼512-->256
        self.equi_dec_convs["upconv_3"] = ConvBlock(self.num_ch_dec[3], self.num_ch_dec[2]) # 256-->128

        self.equi_dec_convs["deconv_2"] = ConvBlock(self.num_ch_dec[2] + self.num_ch_enc[1], self.num_ch_dec[2]) # 128+128拼256-->128
        self.equi_dec_convs["upconv_2"] = ConvBlock(self.num_ch_dec[2], self.num_ch_dec[1]) # 128-->64

        self.equi_dec_convs["deconv_1"] = ConvBlock(self.num_ch_dec[1] + self.num_ch_enc[0], self.num_ch_dec[1]) # 64+128拼192-->64
        self.equi_dec_convs["upconv_1"] = ConvBlock(self.num_ch_dec[1], self.num_ch_dec[0]*16) # 64-->32*16

        self.equi_dec_convs["deconv_0"] = ConvBlock(self.num_ch_dec[0], self.num_ch_dec[0]) # 64-->64

        self.equi_dec_convs["depthconv_0"] = Conv3x3(self.num_ch_dec[0], 3) # 64-->3

        self.equi_decoder = nn.ModuleList(list(self.equi_dec_convs.values()))

        self.sigmoid = nn.Sigmoid()
        #############################################################################################################################
        self.hook = [3, 5, 7, 9, 11]

    def forward(self, x): 
        x = self.to_patch_embedding(x) 
        x += self.pos_embedding 
        x = self.dropout(x)

        features = self.transformer(x) 
        
        ERPx1=vitMatrix2ERP(features[self.hook[0]])
        x1 = self.postprocess1(ERPx1) 
        ERPx2=vitMatrix2ERP(features[self.hook[1]])
        x2 = self.postprocess2(ERPx2)
        ERPx3=vitMatrix2ERP(features[self.hook[2]])
        x3 = self.postprocess3(ERPx3)
        ERPx4=vitMatrix2ERP(features[self.hook[3]])
        x4 = self.postprocess4(ERPx4) 
        ERPx5=vitMatrix2ERP(features[self.hook[4]])
        x5 = self.postprocess5(ERPx5)
        
        return x1, x2, x3, x4, x5
