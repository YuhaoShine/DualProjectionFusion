import torch
import torch.nn.functional as F
import math
import numpy as np


def cub2erp_batch(cubemap, erp_h=256, erp_w=512):
    """
    支持批处理的立方体→ERP投影
    输入: 
        cubemap: [batch_size, 6, 3, 128, 128] (顺序为+/-X, +/-Y, +/-Z)
    返回: 
        [batch_size, 3, erp_h, erp_w] (通道优先格式，便于后续CNN处理)
    """
    device = cubemap.device
    new_order = torch.tensor([0,2,1,3,5,4], device=device) # 03
    cubemap = torch.index_select(cubemap, dim=1, index=torch.tensor(new_order))
    ##
    image_to_flip1 = cubemap[:, 1, :, :, :]
    flipped_image1 = torch.flip(image_to_flip1, dims=[-1]) 
    cubemap[:, 1, :, :, :]=flipped_image1
    ##
    image_to_flip2 = cubemap[:, 2, :, :, :]
    flipped_image2 = torch.flip(image_to_flip2, dims=[-1]) 
    cubemap[:, 2, :, :, :]=flipped_image2
    # ##
    # image_to_flip4 = cubemap[:, 4, :, :, :]
    # flipped_image4 = torch.flip(image_to_flip4, dims=[-2]) 
    # cubemap[:, 4, :, :, :]=flipped_image4
    ##
    image_to_flip5 = cubemap[:, 5, :, :, :]
    flipped_image5 = torch.flip(image_to_flip5, dims=[-1]) 
    cubemap[:, 5, :, :, :]=flipped_image5
    
    batch_size = cubemap.shape[0]
    # cubemap[:,0,1,:,:]=1.0 # face0 红
    # cubemap[:,5,1,:,:]=1.0 # face1 绿
    
    pi = torch.tensor(math.pi)
    
    # Step 1: 预计算所有ERP像素的球面坐标 (共享坐标，无需重复计算)
    theta = torch.linspace(-pi, pi, erp_w, device=device)  # [erp_w]
    phi = torch.linspace(-pi/2, pi/2, erp_h, device=device)  # [erp_h]
    # theta_grid, phi_grid = torch.meshgrid(theta, phi, indexing='xy')  # [erp_w, erp_h]
    theta_grid, phi_grid = torch.meshgrid(theta, phi)  # [erp_w, erp_h]
    theta_grid=theta_grid.T
    phi_grid=phi_grid.T
    
    # Step 2: 球面坐标→3D坐标 (向量化)
    x = torch.cos(phi_grid) * torch.cos(theta_grid)  # [erp_w, erp_h]
    y = torch.cos(phi_grid) * torch.sin(theta_grid)
    z = torch.sin(phi_grid)
    
    # Step 3: 确定每个ERP像素所属的立方体面 (向量化)
    abs_xyz = torch.stack([x.abs(), y.abs(), z.abs()], dim=-1)  # [erp_w, erp_h, 3]
    max_val, face_dim = torch.max(abs_xyz, dim=-1)  # face_dim ∈ {0,1,2} 对应X/Y/Z轴

    # Step 4: 计算立方体面内坐标 (向量化)
    uc = torch.where(
        face_dim == 0, (y / max_val + 1) * 63.5,
        torch.where(
            face_dim == 1, (x / max_val + 1) * 63.5,
            (x / max_val + 1) * 63.5
        )
    )
    vc = torch.where(
        face_dim == 0, (z / max_val + 1) * 63.5,
        torch.where(
            face_dim == 1, (z / max_val + 1) * 63.5,
            (y / max_val + 1) * 63.5
        )
    )
    uc = (uc - 0.5).clamp(0, 127)  # 双线性插值需在[0,127]内
    vc = (vc - 0.5).clamp(0, 127)
    
    
    #???? 上下两极的面没有与+X对齐 
    
    # Step 5: 双线性插值采样 (批量处理)
    # 初始化输出ERP图像 [batch, 3, erp_h, erp_w]
    erp_images = torch.zeros((batch_size, 3, erp_h, erp_w), device=device)
    
    # 对每个立方体面单独处理
    for face in range(6):
        # 确定当前面的像素掩码        
        if face == 0: mask = (face_dim == 0) & (x > 0)  # +X
        elif face == 1: mask = (face_dim == 0) & (x < 0)  # -X
        elif face == 2: mask = (face_dim == 1) & (y > 0)  # +Y
        elif face == 3: mask = (face_dim == 1) & (y < 0)  # -Y
        elif face == 4: mask = (face_dim == 2) & (z > 0)  # +Z
        else: mask = (face_dim == 2) & (z < 0)  # -Z
        
        if not mask.any():
            continue
        
        # 生成采样网格 [batch, N, 1, 2]
        grid = torch.stack([
            2 * uc[mask] / 127 - 1,  # 归一化到[-1,1]
            2 * vc[mask] / 127 - 1
        ], dim=-1).unsqueeze(0).unsqueeze(2).expand(batch_size, -1, -1, -1)
        
        # 从当前面采样 [batch, 3, N, 1]
        sampled = F.grid_sample(
            input=cubemap[:, face],  # [batch, 3, 128, 128]
            grid=grid,              # [batch, N, 1, 2]
            mode='bilinear',
            align_corners=True
        ).squeeze(-1)  # [batch, 3, N]
        
        # 将采样结果填充到ERP图像中
        erp_images[:, :, mask] = sampled
    
    return erp_images  # [batch, 3, erp_h, erp_w]