import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
import torch
import math

from skimage import io, transform
from torchvision import transforms
import numpy as np
import lpips

#==========================
# Depth Prediction Metrics
#==========================

def calculate_psnr(target, prediction):
    # 确保输入图像的尺寸相同
    assert target.shape == prediction.shape, "The shape of target and prediction must be the same."
    # 将图像转换为float类型
    target = target.type(torch.float32)
    prediction = prediction.type(torch.float32)
    # 计算差异
    diff = target - prediction
    diff = torch.abs(diff) 
    # 计算MSE
    mse = torch.mean(diff ** 2)
    # 计算PSNR
    max_pixel_value = 1.0  # 假设图像像素值范围为0-1
    psnr = 20 * math.log10(max_pixel_value / math.sqrt(mse))
    psnr = torch.tensor(psnr)   
    return psnr

# def readRGBPano(Imgpath):
#     rgb = io.imread(Imgpath).astype(np.float32) / 255.
#     #rgb = transform.resize(rgb, (512, 1024))
#     tran = transforms.ToTensor()
#     rgb = tran(rgb)
#     return rgb


def compute_depth_metrics(gt, pred, lpips_model):
    """Computation of metrics between predicted and ground truth depths
    """
    ## 阈值准确率，越大越好
    thresh = torch.max((gt / pred), (pred / gt))
    a1 = (thresh < 1.25     ).float().mean()
    ## 均方误差，越小越好
    rmse = (gt - pred) ** 2
    rmse = torch.sqrt(rmse.mean())
    ## 像素误差，越小越好
    abs_ = torch.mean(torch.abs(gt - pred))
    ## 峰值信噪比，越大越好
    PSNR=calculate_psnr(gt, pred)
    
    ## 学习感知图像块相似度，越小越好：使用预训练的深度网络（如 VGG、AlexNet）来提取图像特征，然后计算这些特征之间的距离，以评估图像之间的感知相似度。
    # lpips_model = lpips.LPIPS(net='vgg', version=0.1) # 可以选择'vgg'或'squeezenet'作为backbone
    # lpips_model = lpips_model.cuda()
    
    ## LUT版本通道是2，需要加一个通道才能调用lpips_model
    # gta=torch.cat((gt, gt[:, :1, :, :]), dim=1)
    # preda=torch.cat((pred, pred[:, :1, :, :]), dim=1)
    # LPIPSs = lpips_model(gta, preda) # 注意bs*c*h*w，例如：1*3*16*32
    LPIPSs = lpips_model(gt, pred)
    LPI=LPIPSs.squeeze()
    LPI = torch.mean(LPI)
    
    # img0 = torch.from_numpy(img0).permute(2, 0, 1).unsqueeze(0)

    return abs_, rmse, a1, PSNR, LPI


# From https://github.com/fyu/drn
class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.vals = []
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.vals.append(val)
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

    def to_dict(self):
        return {
            'val': self.val,
            'sum': self.sum,
            'count': self.count,
            'avg': self.avg
        }

    def from_dict(self, meter_dict):
        self.val = meter_dict['val']
        self.sum = meter_dict['sum']
        self.count = meter_dict['count']
        self.avg = meter_dict['avg']


class Evaluator(object): ##

    def __init__(self, median_align=False):

        self.median_align = median_align
        # Error and Accuracy metric trackers
        self.metrics = {}
        self.metrics["err/abs_"] = AverageMeter()
        self.metrics["err/rms"] = AverageMeter()
        self.metrics["acc/a1"] = AverageMeter()
        self.metrics["acc/PSNR"] = AverageMeter()
        self.metrics["err/LPIPSs"] = AverageMeter()

    def reset_eval_metrics(self):
        """
        Resets metrics used to evaluate the model
        """
        self.metrics["err/abs_"].reset()
        self.metrics["err/rms"].reset()
        self.metrics["acc/a1"].reset()
        self.metrics["acc/PSNR"].reset()
        self.metrics["err/LPIPSs"].reset()

    def compute_eval_metrics(self, gt_depth, pred_depth, lpips_model):
        """
        Computes metrics used to evaluate the model
        """
        N = gt_depth.shape[0]
        
        abs_, rms, a1, PSNR, LPIPSs = compute_depth_metrics(gt_depth, pred_depth, lpips_model)

        self.metrics["err/abs_"].update(abs_, N)
        self.metrics["err/rms"].update(rms, N)
        self.metrics["acc/a1"].update(a1, N)
        self.metrics["acc/PSNR"].update(PSNR, N)
        self.metrics["err/LPIPSs"].update(LPIPSs, N)
        
        return abs_, rms, a1, PSNR, LPIPSs

    def print(self, epoch, dir=None):
        avg_metrics = []
        avg_metrics.append(self.metrics["err/abs_"].avg)
        avg_metrics.append(self.metrics["err/rms"].avg)
        avg_metrics.append(self.metrics["acc/a1"].avg)
        avg_metrics.append(self.metrics["acc/PSNR"].avg)
        avg_metrics.append(self.metrics["err/LPIPSs"].avg)
        avg_metrics.append(epoch)
        
        print("\n  "+ ("{:>9} | " * 5).format("abs_", "rms", "a1", "PSNR", "LPIPSs"))
        print(("&  {: 8.5f} " * 5).format(*avg_metrics))

        if dir is not None:
            file = os.path.join(dir, "backbone_result.txt")
            
            with open(file, 'a') as f:
                print("\n  " + ("{:>9} | " * 6).format("abs_", "rms", "a1", "PSNR", "LPIPSs", "epoch"), file=f)
                print(("&  {: 8.5f} " * 6).format(*avg_metrics), file=f)
        
        
# imgROOT="F:/UprightCorrectionDataset/SUN_Diff_Level_Upright_Rotate16_8_To1024_512/resize16_8/others_R16/" 
# imgName="pano_aaaajqcfdxzbya.jpg"
# gtIMG = io.imread(imgROOT+imgName).astype(np.float32) / 255.
# gtIMG = transform.resize(gtIMG, (16, 32))
# tran = transforms.ToTensor()
# gtIMG = tran(gtIMG)

# imgROOT1="F:/UprightCorrectionDataset/SUN_Diff_Level_Upright_Rotate16_8_To1024_512/resize32_16/others_R32/" 
# imgName1="pano_aaaajqcfdxzbya.jpg"
# predIMG = readRGBPano(imgROOT1+imgName1)
# #predIMG = gtIMG + 0.09 * torch.randn(8, 16)

# correction_errors = compute_depth_metrics(gtIMG, predIMG)
# print(correction_errors)
# ## PSNR峰值信噪比，越大越好